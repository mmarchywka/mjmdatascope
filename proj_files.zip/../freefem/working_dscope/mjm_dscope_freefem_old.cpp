// -*- Mode : c++ -*-
//
// SUMMARY  :
// USAGE    :
// ORG      :
// AUTHOR   : Frederic Hecht
// E-MAIL   : hecht@ann.jussieu.fr
//

/*

 This file is part of Freefem++

 Freefem++ is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation; either version 2.1 of the License, or
 (at your option) any later version.

 Freefem++  is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU Lesser General Public License for more details.


 You should have received a copy of the GNU Lesser General Public License
 along with Freefem++; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mjm_globals.h"
#include "mjm_dscope_interface.h"
// no idea FIXME TODO wtf 
#undef OK 
#include "ff++.hpp"
#include "AFunction_ext.hpp"


#include "lgmesh.hpp"

using Fem2D::Mesh;
using Fem2D::MeshPoint;

extern bool NoWait;

typedef Mesh const * pmesh;


class MjmDscope :  public E_F0 { public:


typedef mjm_dscope_interface<> Dscope;
typedef mjm_ragged_table Ragged;
typedef Ragged::Line Line;
typedef mjm_string_base_params<Dscope::traits_type> BaseParams;
typedef double ValTy;
typedef mjm_block_matrix<ValTy> Block;

   typedef pmesh  Result;
   Expression getmesh,getmeshL;
   Expression filename;
Expression evct;
std::string dscope_init;
   Expression xx,yy,zz;
mutable Dscope m_dscope;
// TODO  need to hide this in dscope
Ragged m_dscope_header;
Ragged m_evct_header;
bool have_evct;



   MjmDscope(const basicAC_F0 & args)
    {
      xx=0;
      yy=0;
      zz=0;
      args.SetNameParam();
      getmesh=to<pmesh>(args[0]);
//      getmeshL=to<pmeshL>(args[0]);
      filename=to<string*>(args[1]);
      dscope_init="rawfifo launch  2"; // std::string(to<string*>(args[2]));
std::stringstream ssf; ssf<<filename;
//if (false) dscope_init=(*filename);
Dscope::traits_type::Ss ss;
ss<<"# id test pattern chunks 0 "<<CRLF;
ss<<"# ffmesh 2D "<<CRLF;
//ss<<"# trace "<<CRLF;
//ss<<""<<CRLF;
m_dscope_header.load(ss,false);
m_dscope.load(dscope_init,0);     
have_evct=false;
 if (args.size() ==3)
{
  evct = to< double >(args[2]);
have_evct=true;
} // 3
 if (args.size() >3)
        {
          const E_Array * a = dynamic_cast<const E_Array *>(args[2].LeftValue());
          if (!a) CompileError("savemesh(Th,\"filename\",[u,v,w],...");
          int k=a->size() ;
         // cout << k << endl;
          if ( k!=2 && k !=3) CompileError("savemesh(Th,\"filename\",[u,v,w]) need 2 or 3  componate in array ",atype<pmesh>());
          xx=to<double>( (*a)[0]);
          yy=to<double>( (*a)[1]);
          if(k==3)
           zz=to<double>( (*a)[2]);
         }

   }
    static ArrayOfaType  typeargs() { return  ArrayOfaType(atype<pmesh>(),atype<string*>(),true);}
    static  E_F0 * f(const basicAC_F0 & args){ return new MjmDscope(args);}
    AnyType operator()(Stack s) const ;

};

AnyType MjmDscope::operator()(Stack stack) const
{
//MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
  using  Fem2D::MeshPointStack;
  const  Fem2D::Mesh * Thh = GetAny<pmesh>((*getmesh)(stack));
   string * fn =  GetAny<string*>((*filename)(stack));
//MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
   if (!xx && !yy ) {
MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
Ragged r; 
r=m_dscope_header;
    const Mesh &Thtmp = *Thh;;
 int   nv = Thtmp.nv;
  int  nt = Thtmp.nt;
  int  nbe = Thtmp.neb;
// just write the mesh format
r.new_line();
r<<nv; r<<nt; r<<nbe; 
r.new_line();
    for (int ii = 0; ii < Thtmp.nv; ii++) {
      const Mesh::Vertex &vi(Thtmp(ii));
r<<vi.x; r<<vi.y; r<<vi.lab; 
r.new_line();

    }

int kkk=1;
    for (int ii = 0; ii < Thtmp.nt; ii++) {
      const Mesh::Triangle &vi(Thtmp.t(ii));
      int i0 = kkk+  Thtmp(ii, 0);
      int i1 = kkk+ Thtmp(ii, 1);
      int i2 = kkk+ Thtmp(ii, 2);
r<<i0; r<<i1; r<<i2; r<<vi.lab;
r.new_line();
    }
    for (int ii = 0; ii < Thtmp.neb; ii++) {
      const Mesh::BorderElement &vi(Thtmp.be(ii));    // 
      int i0 = kkk+ Thtmp.operator( )(vi[0]);
      int i1 =  kkk+Thtmp.operator( )(vi[1]);
r<<i0; r<<i1; r<<vi.lab;
r.new_line();
    }
m_dscope.send(r,Block(),0);
// from marchywka@happy:/home/ubuntu/dev/freefem/FreeFem-sources-4.12/plugin/seq$ vi VTK_writer.cpp 

if (have_evct)
{
int nbsol=nv;
  KN< double > valsol(nbsol);
  valsol = 0.;
  KN< int > takemesh(nbsol);
  takemesh = 0;
  MeshPoint *mp3(MeshPointStack(stack));

  for (int it = 0; it < nt; it++) {
    for (int iv = 0; iv < 3; iv++) {
      int i = (*Thh)(it, iv);
      mp3->setP(Thh, it, iv);
      valsol[i] = valsol[i] + GetAny< double >((*evct)(stack));
      ++takemesh[i];
    }
  }

  for (int i = 0; i < nbsol; i++) {
    valsol[i] /= takemesh[i];
  }
r=m_evct_header;
m_dscope.send(r,Block(),0);
} // have_evct


///////////////////////////////////////////////////////////

     }
   else {
MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
    MeshPoint *mp(MeshPointStack(stack)) , mps=*mp;
MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
     ofstream fp((*fn+".points").c_str());
     ofstream ff((*fn+".faces").c_str());
     fp.precision(12);
MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
     if (verbosity>1)
       cout << "  -- Opening files " << (*fn+".points") << " and " << (*fn+".faces") << endl;
    const   Fem2D::Mesh & Th=*Thh;
    long nbv=Thh->nv;
    long nbt=Thh->nt;
    ff << nbt << endl;
    fp << nbv << endl;
    KN<long> num(nbv);
    num=-1;
    int k=0;
    for (int it=0;it<nbt;it++)
      {
        const Fem2D::Triangle & K(Th[it]);

        num[Th(K[0])]=k++;
        num[Th(K[1])]=k++;
        num[Th(K[2])]=k++;

         ff << " 3 " << Th(K[0])+1 << ' ' << Th(K[1])+1 << ' ' << Th(K[2])+1 << ' '
         	<< " 0 0 0 " << K.lab << '\n';
      }
    if( verbosity>5)
     cout << "  - end writing faces  " << endl;
    for (int iv=0;iv<nbv;iv++)
      {
        const Fem2D::Vertex  & v(Th(iv));
        ffassert( iv == Th(num[iv]/3,num[iv]%3));
        mp->setP(Thh,num[iv]/3,num[iv]%3);

        fp << GetAny<double>((*xx)(stack)) << ' ';
        fp << GetAny<double>((*yy)(stack)) << ' ';
        if (zz)
         fp << GetAny<double>((*zz)(stack)) << ' ';
        else
         fp << " 0 ";
        fp << v.lab<< '\n';
      }
    if( verbosity>5)
     cout << "  - end writing points  " << endl;

   *mp= mps;

   }
  //  delete fn;   modif mars 2006 auto del ptr
   return SetAny<pmesh>(Thh);
}

////////////////////////////////////////////////////////////////

class MjmDscopeL :  public E_F0 { public:


typedef mjm_dscope_interface<> Dscope;
typedef mjm_ragged_table Ragged;
typedef Ragged::Line Line;
typedef mjm_string_base_params<Dscope::traits_type> BaseParams;
typedef double ValTy;
typedef mjm_block_matrix<ValTy> Block;

   typedef pmesh  Result;
   Expression getmeshL;
   Expression filename;
std::vector<Expression> m_exp;
std::string dscope_init;
   Expression xx,yy,zz;
mutable Dscope m_dscope;
// TODO  need to hide this in dscope
Ragged m_dscope_header;
Ragged m_evct_header;


   MjmDscopeL(const basicAC_F0 & args)
    {
      xx=0;
      yy=0;
      zz=0;
      args.SetNameParam();
      getmeshL=to<pmeshL>(args[0]);
//      getmeshL=to<pmeshL>(args[0]);
      filename=to<string*>(args[1]);
      dscope_init="rawfifo launch  2"; // std::string(to<string*>(args[2]));
std::stringstream ssf; ssf<<filename;
//if (false) dscope_init=(*filename);
Dscope::traits_type::Ss ss;
ss<<"# id test pattern chunks 0 "<<CRLF;
ss<<"# time-snap 1D "<<CRLF;
ss<<"# trace "<<CRLF;
//ss<<"# trace "<<CRLF;
//ss<<""<<CRLF;
//m_dscope_header.load(ss,false);
m_evct_header.load(ss,false);
m_dscope.load(dscope_init,0);     
for(int i=2; i<args.size(); ++i) m_exp.push_back( to< double >(args[i]));

   } // compile time ctor
    static ArrayOfaType  typeargs() { return  ArrayOfaType(atype<pmeshL>(),atype<string*>(),true);}
    static  E_F0 * f(const basicAC_F0 & args){ return new MjmDscopeL(args);}
    AnyType operator()(Stack s) const ;

}; // MjmDscopeL
// home/ubuntu/dev/freefem/FreeFem-sources-4.12/plugin/seq$ vi vortextools.cpp 
// runtime code 
AnyType MjmDscopeL::operator()(Stack stack) const
{
//typedef unsigned int IdxTy;
typedef int IdxTy;
//MM_ERR(" je suis dans "<<MMPR(__FUNCTION__))
string * params =  GetAny<string*>((*filename)(stack));
  using  Fem2D::MeshPointStack;
  const  MeshL & Th =* GetAny<pmeshL>((*getmeshL)(stack));
    typedef MeshL::Element Element;
    typedef MeshL::Vertex Vertex;
    int nt=Th.nt,nv=Th.nv;
//if (!have_evct&&(m_exp.size()==0))
// send the mesh onnly 
if (m_exp.size()==0)
{
Ragged r=m_dscope_header;
std::stringstream ss;
ss<<"# "<<*params;
r.load(ss,false);
 //   KN< int > cn(nv);
 //   KN< double > le(nv);
    for(int k=0;k<nv;k++){
//        const Element & E(Th[k]);
      const Vertex &vi(Th(k));
//MM_ERR(MMPR4(k,vi.x,vi.y,vi.z))

    //    double lE = E.mesure();
    //    R3 EV(E[0],E[1]);// vector 

}
m_dscope.send(r,Block(),0);
} // mesh only 
if ((0!=m_exp.size()))
{
Ragged r=m_evct_header;
std::stringstream ss;
ss<<"# "<<*params;
r.load(ss,false);
int nbsol=nv;
Block b(nbsol,m_exp.size()+1);
//MM_ERR(MMPR2(nv,nt))
 std::vector< KN< double > >  vvalsol(m_exp.size());
//MM_TRACE
MM_LOOP(ii,vvalsol) {(*ii).resize(nbsol); } 
//MM_TRACE
MM_SZ_LOOP(ii,vvalsol,szvv)
{
  KN< double >& valsol=vvalsol[ii];
//MM_ERR(MMPR2(ii,valsol.size()))
valsol=double(0);
//MM_ERR(MMPR2(ii,valsol.size()))
  KN< int > takemesh(nbsol);
  takemesh = 0;
  MeshPoint *mp3(MeshPointStack(stack));

  for (int it = 0; it < nt; it++) {
    for (int iv = 0; iv < 2; iv++) {
      int i = Th(it, iv);
//MM_ERR(MMPR2(iv,i))
      mp3->setP(&Th, it, iv); 
      valsol[i] = valsol[i] + GetAny< double >((*m_exp[ii])(stack));
      ++takemesh[i];
    }
  }

  for (int i = 0; i < nbsol; i++) {
    valsol[i] /= takemesh[i];
  }
MM_SZ_LOOP(j,valsol,szv){ b(j,ii)=valsol[j];

//MM_ERR(MMPR3(j,ii,valsol[j]))
}
} // i 

//MM_TRACE
    for(int k=0;k<nv;k++){
      const Vertex &vi(Th(k));
//MM_ERR(MMPR(k))
//MM_ERR(MMPR2(k,valsol[k]))
//MM_ERR(MMPR4(k,vi.x,vi.y,vi.z)<<MMPR(valsol[k]))
b(k,m_exp.size())=vi.x;
} // for k 

//MM_TRACE

m_dscope.send(r,b,0);
} // m_exp
   return SetAny<pmeshL>(&Th);
}


static void init_mjmdscope() {
//  if(verbosity&&(mpirank==0) )  cout <<"datascope ";
// old 2 D mesh display 
  Global.Add("mjmdscope","(",new OneOperatorCode<MjmDscope>);
// display meshL oscilloscope format using 
  Global.Add("mjmdscopeL","(",new OneOperatorCode<MjmDscopeL>);
    
}
LOADFUNC(init_mjmdscope);
